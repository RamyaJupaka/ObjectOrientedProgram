﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;
namespace finalexam_ramya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fbt_exit_Click(object sender, EventArgs e)
        {
            byte fbt_exit_result = 0;
            fbt_exit_result = Convert.ToByte(
            MessageBox.Show("Do you really want to exit the app?", "Exit Ramya", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
            this.Close();
        }

        private void ftx_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void fbt_validate_Click(object sender, EventArgs e)
        {
            Regex rgxName = new Regex(@"^[a-zA-Z]{2}([a-zA-Z\s]){0,48}$");
            if (!rgxName.IsMatch(ftx_name.Text))
            {
                MessageBox.Show("Data 1: enter a valid name!\n 2 up to 50 characters.");
            }
            else
            {
                ftx_name.Enabled = false;
                ftx_course.Enabled = true;
            }
            Regex rgxCourse = new Regex(@"^[0-9]{3}\-[A-Z][0-9]{1 ,3}\-[A-Z]{2}$");
            if (!rgxName.IsMatch(ftx_name.Text))
            {
                MessageBox.Show("Data 2: enter a valid course ID!\n ex: 420.");
            }
            else
            {
                ftx_course.Enabled = false;
                ftx_session.Enabled = true;
            }
            Regex rgxSession = new Regex(@"(Summer)|(Winter)|(Fall)");
            if (!rgxName.IsMatch(ftx_name.Text))
            {
                MessageBox.Show("Data 3: seslect a valid session .");
            }
            else
            {
                ftx_session.Enabled = false;
                ftx_year.Enabled = true;

            }
            Regex rgxYear = new Regex(@"(2018)|(2019)");
            if (!rgxName.IsMatch(ftx_name.Text))
            {
                MessageBox.Show("Data 4: seslect a valid year \n 2018 or 2019 .");
            }
            else
            {
                ftx_year.Enabled = false;

            }

        }


        private void fbt_write_Click(object sender, EventArgs e)
        {
            if (!ftx_name.Enabled && !ftx_course.Enabled && !ftx_session.Enabled && !ftx_year.Enabled && !ftx_midbox1.Enabled && !ftx_projectbox1.Enabled && !ftx_finalbox1.Enabled && !ftx_totalbox1.Enabled)
            {
                validText = true;
                //code using a class
                user = new User(ftx_name.Text, ftx_course.Text, ftx_session.Text, Convert.ToInt32(ftx_year.Text), Convert.ToInt32(ftx_midbox1), Convert.ToInt32(ftx_projectbox1), Convert.ToInt32(ftx_finalbox1), Convert.ToInt32(ftx_totalbox1)); //create a new object user calling the constructor with values
                if (user.WriteTXT())
                {
                    MessageBox.Show("The user was appended to the text file.");
                    //textBox1.Enabled = true;
                    //button1.Enabled = true;
                    //textBox2.Enabled = true;
                    //button2.Enabled = true;
                    //textBox3.Enabled = true;
                    //button3.Enabled = true;
                }
            }
        }
        private void fbt_create_xml_Click(object sender, EventArgs e)
        {

        }
        public static string dir = @"./S2018/";
        public static FileStream fs = null;
        public static bool validText = false;
        public static User user;
        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
            user = new User(); //create a new object user calling the default constructor (members = default values)
        }

        private void fbt_read_xml_Click(object sender, EventArgs e)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            // create the XmlReader object using settings object
            XmlReader xmlIn = XmlReader.Create(dir + "Final.xml", settings);
            string Value1 = "", Value2 = "", Value3 = "", Value4 = "", Value5 = "", Value6 = "", Value7 = "", Value8 = "", tempStr = "";
            // read past all nodes to the first <User> node
            if (xmlIn.ReadToDescendant("User"))
            {
                do
                {
                    xmlIn.ReadStartElement("User");
                    Value1 = xmlIn.ReadElementContentAsString(); //<FullName>
                    Value2 = xmlIn.ReadElementContentAsString(); //<Course>
                    Value3 = xmlIn.ReadElementContentAsString(); //<Session>
                    Value4 = xmlIn.ReadElementContentAsString(); //<year>
                    Value5 = xmlIn.ReadElementContentAsString(); //<mid>
                    Value6 = xmlIn.ReadElementContentAsString(); //<project>
                    Value7 = xmlIn.ReadElementContentAsString(); //<final>
                    Value8 = xmlIn.ReadElementContentAsString(); //<total>

                    tempStr += Value1 + ", " + Value2 + ", " + Value3 + "," + Value4 + "," + Value5 + "," + Value6 + "," + Value7 + "," + Value8 + ",\r\n";
                } while (xmlIn.ReadToNextSibling("User"));
            }
            MessageBox.Show(tempStr); //Show the elements of all the Users nodes in one MessageBox
            // close the XmlReader object
            xmlIn.Close();
        }

        private void fbt_calculate_Click(object sender, EventArgs e)
        {
          
           

            int num1 = Convert.ToInt32(ftx_midbox1.Text);
            if (num1 <= 60 && num1 >=60)
            {
                ftx_midbox11.Text = Convert.ToString(num1 / 100 * 30);
                ftx_midbox11.Text = "";
            }
            int num2 = Convert.ToInt32(ftx_projectbox1.Text);
            if (num2 <= 100 && num2 >=60)
            {
                ftx_midbox11.Text = Convert.ToString(num2 / 100 * 30);
                ftx_midbox11.Text = "";
            }
            int num3 = Convert.ToInt32(ftx_finalbox1.Text);
            if (num3 <= 100 && num3 >= 60)
            {
                ftx_midbox11.Text = Convert.ToString(num3 / 100 * 30);
                ftx_midbox11.Text = "";
            }

            ftx_totalbox1.Text = Convert.ToString(num1+num2+num3);

            //ftx_totalbox11 = Convert.ToString(ftx_midbox11.Text + ftx_projectbox11.Text + ftx_finalbox11.Text) ;


        }
        public partial class User
        {   //private members
            private string full_name, course, session;
            int year , mid , project , final,total;
            //public Proprietes
            public string Full_name
            {
                get { return full_name; }
                set { full_name = value; }
            }
            public string Course
            {
                get { return course; }
                set { course = value; }
            }
            public string Session
            {
                get { return session; }
                set { session = value; }
            }
            public int Year
            {
                get { return year; }
                set { year = value; }
            }
            public int Mid
            {
                get { return mid; }
                set { mid = value; }
            }
            public int Project
            {
                get { return project; }
                set { project = value; }
            }
            public int Final
            {
                get { return final; }
                set { final = value; }
            }
            public int Total
            {
                get { return total; }
                set { total = value; }
            }
            //public constructors
            public User() { }
            public User(string s1, string s2, string s3, int s4, int s5, int s6, int s7, int s8)
            {
                Full_name = s1;
                Course = s2;
                Session = s3;
                Year = s4;
                mid = s5;
                project = s6;
                final = s7;
                total = s8;

            }
            public bool WriteTXT()
            {
                try
                {
                    Form1.fs = new FileStream(Form1.dir + "Final.txt", FileMode.Append, FileAccess.Write);

                    // create the output stream for a text file that exists
                    StreamWriter textOut = new StreamWriter(Form1.fs);

                    if (Form1.validText)
                    {
                        // write the fields into text file
                        textOut.Write(Full_name + "|");
                        textOut.Write(Course + "|");
                        textOut.Write(Session + "|");
                        textOut.WriteLine(Year);
                        textOut.WriteLine(mid);
                        textOut.WriteLine(project);
                        textOut.WriteLine(final);
                        textOut.WriteLine(total);

                    }
                    // close the output stream for the text file
                    textOut.Close();
                    return true;
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(Form1.dir + "Final.txt" + " not found.", "File Not Found");
                    return false;
                }
                catch (DirectoryNotFoundException)
                {
                    MessageBox.Show(Form1.dir + " not found.", "Directory Not Found");
                    return false;
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message, "IOException");
                    return false;
                }
                finally { if (Form1.fs != null) Form1.fs.Close(); }
            }
        }
    }
}

