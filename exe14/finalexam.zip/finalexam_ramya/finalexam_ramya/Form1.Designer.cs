﻿namespace finalexam_ramya
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.fbt_validate = new System.Windows.Forms.Button();
            this.ftx_year = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ftx_session = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ftx_course = new System.Windows.Forms.TextBox();
            this.ftx_name = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ftx_totalbox11 = new System.Windows.Forms.TextBox();
            this.ftx_finalbox11 = new System.Windows.Forms.TextBox();
            this.ftx_projectbox11 = new System.Windows.Forms.TextBox();
            this.ftx_midbox11 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ftx_totalbox1 = new System.Windows.Forms.TextBox();
            this.ftx_finalbox1 = new System.Windows.Forms.TextBox();
            this.ftx_projectbox1 = new System.Windows.Forms.TextBox();
            this.ftx_midbox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.fbt_write = new System.Windows.Forms.Button();
            this.fbt_create_xml = new System.Windows.Forms.Button();
            this.fbt_read_xml = new System.Windows.Forms.Button();
            this.fbt_exit = new System.Windows.Forms.Button();
            this.fbt_calculate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Course Number:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fbt_validate);
            this.groupBox1.Controls.Add(this.ftx_year);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.ftx_session);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ftx_course);
            this.groupBox1.Controls.Add(this.ftx_name);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(40, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1060, 168);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // fbt_validate
            // 
            this.fbt_validate.Location = new System.Drawing.Point(926, 124);
            this.fbt_validate.Name = "fbt_validate";
            this.fbt_validate.Size = new System.Drawing.Size(98, 38);
            this.fbt_validate.TabIndex = 8;
            this.fbt_validate.Text = "validate";
            this.fbt_validate.UseVisualStyleBackColor = true;
            this.fbt_validate.Click += new System.EventHandler(this.fbt_validate_Click);
            // 
            // ftx_year
            // 
            this.ftx_year.Location = new System.Drawing.Point(767, 100);
            this.ftx_year.Name = "ftx_year";
            this.ftx_year.Size = new System.Drawing.Size(100, 26);
            this.ftx_year.TabIndex = 7;
            this.ftx_year.Text = "2018";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(717, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Year";
            // 
            // ftx_session
            // 
            this.ftx_session.FormattingEnabled = true;
            this.ftx_session.ItemHeight = 20;
            this.ftx_session.Items.AddRange(new object[] {
            "Summer",
            "Winter",
            "Fall"});
            this.ftx_session.Location = new System.Drawing.Point(468, 101);
            this.ftx_session.Name = "ftx_session";
            this.ftx_session.Size = new System.Drawing.Size(153, 24);
            this.ftx_session.TabIndex = 5;
            this.ftx_session.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(391, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Session:";
            // 
            // ftx_course
            // 
            this.ftx_course.Location = new System.Drawing.Point(164, 94);
            this.ftx_course.Name = "ftx_course";
            this.ftx_course.Size = new System.Drawing.Size(162, 26);
            this.ftx_course.TabIndex = 3;
            this.ftx_course.Text = "420-???-AS";
            // 
            // ftx_name
            // 
            this.ftx_name.Location = new System.Drawing.Point(164, 47);
            this.ftx_name.Name = "ftx_name";
            this.ftx_name.Size = new System.Drawing.Size(860, 26);
            this.ftx_name.TabIndex = 2;
            this.ftx_name.Text = "Enter your Name";
            this.ftx_name.TextChanged += new System.EventHandler(this.ftx_name_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ftx_totalbox11);
            this.groupBox2.Controls.Add(this.ftx_finalbox11);
            this.groupBox2.Controls.Add(this.ftx_projectbox11);
            this.groupBox2.Controls.Add(this.ftx_midbox11);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.ftx_totalbox1);
            this.groupBox2.Controls.Add(this.ftx_finalbox1);
            this.groupBox2.Controls.Add(this.ftx_projectbox1);
            this.groupBox2.Controls.Add(this.ftx_midbox1);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(40, 233);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1060, 262);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // ftx_totalbox11
            // 
            this.ftx_totalbox11.Location = new System.Drawing.Point(873, 94);
            this.ftx_totalbox11.Name = "ftx_totalbox11";
            this.ftx_totalbox11.ReadOnly = true;
            this.ftx_totalbox11.Size = new System.Drawing.Size(100, 26);
            this.ftx_totalbox11.TabIndex = 24;
            this.ftx_totalbox11.Text = "0";
            this.ftx_totalbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_finalbox11
            // 
            this.ftx_finalbox11.Location = new System.Drawing.Point(268, 192);
            this.ftx_finalbox11.Name = "ftx_finalbox11";
            this.ftx_finalbox11.ReadOnly = true;
            this.ftx_finalbox11.Size = new System.Drawing.Size(100, 26);
            this.ftx_finalbox11.TabIndex = 23;
            this.ftx_finalbox11.Text = "0";
            this.ftx_finalbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_projectbox11
            // 
            this.ftx_projectbox11.Location = new System.Drawing.Point(268, 115);
            this.ftx_projectbox11.Name = "ftx_projectbox11";
            this.ftx_projectbox11.ReadOnly = true;
            this.ftx_projectbox11.Size = new System.Drawing.Size(100, 26);
            this.ftx_projectbox11.TabIndex = 22;
            this.ftx_projectbox11.Text = "0";
            this.ftx_projectbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_midbox11
            // 
            this.ftx_midbox11.Location = new System.Drawing.Point(268, 35);
            this.ftx_midbox11.Name = "ftx_midbox11";
            this.ftx_midbox11.ReadOnly = true;
            this.ftx_midbox11.Size = new System.Drawing.Size(100, 26);
            this.ftx_midbox11.TabIndex = 21;
            this.ftx_midbox11.Text = "0";
            this.ftx_midbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(792, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 20);
            this.label17.TabIndex = 20;
            this.label17.Text = "60 - 100 to pass";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(875, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 20);
            this.label16.TabIndex = 19;
            this.label16.Text = "A,B,C,D or F";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(728, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 20);
            this.label15.TabIndex = 18;
            this.label15.Text = "0 to 100";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(283, 227);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "0 to 40%";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(283, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 20);
            this.label13.TabIndex = 16;
            this.label13.Text = "0 to 30%";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(283, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 20);
            this.label12.TabIndex = 15;
            this.label12.Text = "0 to 30%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(135, 227);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 20);
            this.label11.TabIndex = 14;
            this.label11.Text = "0 to 100";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(135, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 20);
            this.label10.TabIndex = 13;
            this.label10.Text = "0 to 100";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(135, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 20);
            this.label9.TabIndex = 12;
            this.label9.Text = "0 to 100";
            // 
            // ftx_totalbox1
            // 
            this.ftx_totalbox1.Location = new System.Drawing.Point(721, 94);
            this.ftx_totalbox1.Name = "ftx_totalbox1";
            this.ftx_totalbox1.Size = new System.Drawing.Size(100, 26);
            this.ftx_totalbox1.TabIndex = 7;
            this.ftx_totalbox1.Text = "0";
            this.ftx_totalbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_finalbox1
            // 
            this.ftx_finalbox1.Location = new System.Drawing.Point(115, 192);
            this.ftx_finalbox1.Name = "ftx_finalbox1";
            this.ftx_finalbox1.Size = new System.Drawing.Size(100, 26);
            this.ftx_finalbox1.TabIndex = 6;
            this.ftx_finalbox1.Text = "0";
            this.ftx_finalbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_projectbox1
            // 
            this.ftx_projectbox1.Location = new System.Drawing.Point(115, 110);
            this.ftx_projectbox1.Name = "ftx_projectbox1";
            this.ftx_projectbox1.Size = new System.Drawing.Size(100, 26);
            this.ftx_projectbox1.TabIndex = 5;
            this.ftx_projectbox1.Text = "0";
            this.ftx_projectbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ftx_midbox1
            // 
            this.ftx_midbox1.Location = new System.Drawing.Point(115, 35);
            this.ftx_midbox1.Name = "ftx_midbox1";
            this.ftx_midbox1.Size = new System.Drawing.Size(100, 26);
            this.ftx_midbox1.TabIndex = 4;
            this.ftx_midbox1.Text = "0";
            this.ftx_midbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(657, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 20);
            this.label8.TabIndex = 3;
            this.label8.Text = "Total:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 198);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Final:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Project:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Midterm:";
            // 
            // fbt_write
            // 
            this.fbt_write.Location = new System.Drawing.Point(244, 543);
            this.fbt_write.Name = "fbt_write";
            this.fbt_write.Size = new System.Drawing.Size(151, 81);
            this.fbt_write.TabIndex = 5;
            this.fbt_write.Text = "Write/Add student data into Final.txt";
            this.fbt_write.UseVisualStyleBackColor = true;
            this.fbt_write.Click += new System.EventHandler(this.fbt_write_Click);
            // 
            // fbt_create_xml
            // 
            this.fbt_create_xml.Location = new System.Drawing.Point(416, 543);
            this.fbt_create_xml.Name = "fbt_create_xml";
            this.fbt_create_xml.Size = new System.Drawing.Size(151, 81);
            this.fbt_create_xml.TabIndex = 6;
            this.fbt_create_xml.Text = "Create/Write Xml Final.xml file from text file";
            this.fbt_create_xml.UseVisualStyleBackColor = true;
            this.fbt_create_xml.Click += new System.EventHandler(this.fbt_create_xml_Click);
            // 
            // fbt_read_xml
            // 
            this.fbt_read_xml.Location = new System.Drawing.Point(582, 543);
            this.fbt_read_xml.Name = "fbt_read_xml";
            this.fbt_read_xml.Size = new System.Drawing.Size(151, 81);
            this.fbt_read_xml.TabIndex = 7;
            this.fbt_read_xml.Text = "Read Xml Final.xml file";
            this.fbt_read_xml.UseVisualStyleBackColor = true;
            this.fbt_read_xml.Click += new System.EventHandler(this.fbt_read_xml_Click);
            // 
            // fbt_exit
            // 
            this.fbt_exit.Location = new System.Drawing.Point(937, 543);
            this.fbt_exit.Name = "fbt_exit";
            this.fbt_exit.Size = new System.Drawing.Size(163, 55);
            this.fbt_exit.TabIndex = 8;
            this.fbt_exit.Text = "E&xit App";
            this.fbt_exit.UseVisualStyleBackColor = true;
            this.fbt_exit.Click += new System.EventHandler(this.fbt_exit_Click);
            // 
            // fbt_calculate
            // 
            this.fbt_calculate.Location = new System.Drawing.Point(68, 542);
            this.fbt_calculate.Name = "fbt_calculate";
            this.fbt_calculate.Size = new System.Drawing.Size(151, 81);
            this.fbt_calculate.TabIndex = 9;
            this.fbt_calculate.Text = "Validate-Calculate Data";
            this.fbt_calculate.UseVisualStyleBackColor = true;
            this.fbt_calculate.Click += new System.EventHandler(this.fbt_calculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 635);
            this.Controls.Add(this.fbt_calculate);
            this.Controls.Add(this.fbt_exit);
            this.Controls.Add(this.fbt_read_xml);
            this.Controls.Add(this.fbt_create_xml);
            this.Controls.Add(this.fbt_write);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Ramya-1834243-8/5/2019";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox ftx_session;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ftx_course;
        private System.Windows.Forms.TextBox ftx_name;
        private System.Windows.Forms.TextBox ftx_year;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ftx_totalbox1;
        private System.Windows.Forms.TextBox ftx_finalbox1;
        private System.Windows.Forms.TextBox ftx_projectbox1;
        private System.Windows.Forms.TextBox ftx_midbox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button fbt_write;
        private System.Windows.Forms.Button fbt_create_xml;
        private System.Windows.Forms.Button fbt_read_xml;
        private System.Windows.Forms.Button fbt_exit;
        private System.Windows.Forms.TextBox ftx_totalbox11;
        private System.Windows.Forms.TextBox ftx_finalbox11;
        private System.Windows.Forms.TextBox ftx_projectbox11;
        private System.Windows.Forms.TextBox ftx_midbox11;
        private System.Windows.Forms.Button fbt_validate;
        private System.Windows.Forms.Button fbt_calculate;
    }
}

